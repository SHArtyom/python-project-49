# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/SHArtyom/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SHArtyom/python-project-49/actions)\n<a href="https://codeclimate.com/github/SHArtyom/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/3b50867d543831c0e321/maintainability" /></a>\n##Scripts demo\n\n### \'brain-even\'\n\n[![asciicast](https://asciinema.org/a/kNIr1rpq8h3P2sxisdfncE1GD.svg)](https://asciinema.org/a/kNIr1rpq8h3P2sxisdfncE1GD)\n\n### \'brain-calc\'\n\n[![asciicast](https://asciinema.org/a/ykJGNq4aotUwUhtBIe3XYEI3T.svg)](https://asciinema.org/a/ykJGNq4aotUwUhtBIe3XYEI3T)\n\n### \'brain-gcd\'\n\n[![asciicast](https://asciinema.org/a/bMatxmXo6aITVpKoP3k48GpHu.svg)](https://asciinema.org/a/bMatxmXo6aITVpKoP3k48GpHu)\n\n### \'brain-progression\'\n\n[![asciicast](https://asciinema.org/a/6BmlvTjr8CUFFb2E1PWqZNRl5.svg)](https://asciinema.org/a/6BmlvTjr8CUFFb2E1PWqZNRl5)\n\n### \'brain-prime\'\n\n[![asciicast](https://asciinema.org/a/N7i3zWTiFJNLeiNByE7gB9ceX.svg)](https://asciinema.org/a/N7i3zWTiFJNLeiNByE7gB9ceX)\n',
    'author': 'SHArtyom',
    'author_email': 'sartiom1@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
