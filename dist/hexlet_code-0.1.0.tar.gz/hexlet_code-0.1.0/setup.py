# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'A small entartaining project with 5 simple mathematical games.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/SHArtyom/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/SHArtyom/python-project-49/actions)\n<a href="https://codeclimate.com/github/SHArtyom/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/3b50867d543831c0e321/maintainability" /></a>\n____\n\n# Description\n\nThis project is a small entartainment package of 5 console mathematical games.\nYou have to give 3 correct answers for each quiz, wrong answer terminates game.\n\n- brain-even\nGuess whether the shown number is even or not. (italic)\n\n- brain-calc\nGuess the result of simple mathematicle expression. (italic)\n\n- brain-gcd\nGuess the greatest common divisor of two given numners. (italic)\n\n- brain-progression\nGuess the missing number in given progression. (italic)\n\n- brain-prime\nGuess whether the given number is prime or not. (italic)\n____\n\n## Minimum requirements\n\n`python3.9`\n____\n\n## Installation guide\n\nTo install the package for an end-user:\n\n`python3 -m pip install --user dist/*.whl`\n\nIf you would like to install it as a developer:\n\nTo install all dependencies execute:\n`make install`\nTo build a package execute:\n`make build`\nTo install the package execute:\n`make package-install`\n____\n\n## Scripts demo\n\n### package installation\n\n[![asciicast](https://asciinema.org/a/dSiVu20g0aHv1jX2eQjGRs5ps.svg)](https://asciinema.org/a/dSiVu20g0aHv1jX2eQjGRs5ps)\n\n### brain-even\n\n[![asciicast](https://asciinema.org/a/kNIr1rpq8h3P2sxisdfncE1GD.svg)](https://asciinema.org/a/kNIr1rpq8h3P2sxisdfncE1GD)\n\n### brain-calc\n\n[![asciicast](https://asciinema.org/a/ykJGNq4aotUwUhtBIe3XYEI3T.svg)](https://asciinema.org/a/ykJGNq4aotUwUhtBIe3XYEI3T)\n\n### brain-gcd\n\n[![asciicast](https://asciinema.org/a/bMatxmXo6aITVpKoP3k48GpHu.svg)](https://asciinema.org/a/bMatxmXo6aITVpKoP3k48GpHu)\n\n### brain-progression\n\n[![asciicast](https://asciinema.org/a/6BmlvTjr8CUFFb2E1PWqZNRl5.svg)](https://asciinema.org/a/6BmlvTjr8CUFFb2E1PWqZNRl5)\n\n### brain-prime\n\n[![asciicast](https://asciinema.org/a/N7i3zWTiFJNLeiNByE7gB9ceX.svg)](https://asciinema.org/a/N7i3zWTiFJNLeiNByE7gB9ceX)\n',
    'author': 'Artyom Shestakov',
    'author_email': 'sartiom1@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/SHArtyom/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
